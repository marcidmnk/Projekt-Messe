using Microsoft.AspNetCore.Mvc;

namespace MesseAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MesseController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Test"
    };

      

       
        [HttpPost]
        public InfoItem Post(InfoItem requestItem)

        {
            InfoItem confirmItem = new InfoItem();
           

            if (!string.IsNullOrEmpty(requestItem.Nachname) && !string.IsNullOrEmpty(requestItem.Vorname))
            {
               confirmItem.Username= requestItem.Vorname+"."+requestItem.Nachname; 
               confirmItem.Confirmed= true;
                                

            }
            else
            {
                confirmItem.Confirmed = false;
            }

            return confirmItem;
        }
    }
}