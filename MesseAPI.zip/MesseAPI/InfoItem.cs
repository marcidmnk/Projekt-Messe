﻿using System.Security.Cryptography.X509Certificates;
using Messe_Januar;

namespace MesseAPI
{
    public class InfoItem
    {
        public string Nachname { get; set; }
        public string Vorname { get; set; }
        public string Username { get; set; }

        public bool Confirmed { get; set; }
        public DateTime RequestTime { get; set; }

       
    }
}
